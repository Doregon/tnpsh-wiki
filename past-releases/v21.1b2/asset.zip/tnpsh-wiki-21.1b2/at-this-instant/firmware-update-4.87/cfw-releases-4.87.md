# 4.87 Releases

## CFW Releases

[FERROX 4.87 with Cobra 8.20](https://www.cybermodding.it/content.php?1061-Custom-Firmware-FERROX-4-87-COBRA-8-20) \(The website is in Italian so you might want to translate the website beforehand\)

[PS3HEN 3.0.2 and HFW 4.87.1](https://github.com/Doregon/tnpsh-wiki/tree/0cbeccc939795e6fbc2c91e56a1cb1243746827b/at-this-instant/firmware-update-4.87/ps3xploit.com)

## Homebrew Updates

[Control Fan Utility 4.87](https://store.brewology.com/ahomebrew.php?brewid=234)

[Unofficial REBUG Toolbox 4.87](https://www.psx-place.com/threads/cfw-4-87-2-evilnat-cobra-cex.32057/page-13#post-270563)

## Tools

[PS3UART by Mina Ralwasser](https://twitter.com/minaralwasser/status/1346569260055855105)

[bguerville toolset v1.1](https://github.com/Doregon/tnpsh-wiki/tree/0cbeccc939795e6fbc2c91e56a1cb1243746827b/at-this-instant/firmware-update-4.87/ps3xploit.net/bguerville/README.md)

