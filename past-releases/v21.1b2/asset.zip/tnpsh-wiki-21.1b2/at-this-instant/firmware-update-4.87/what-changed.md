# What changed?

## Not much.

Really. Sony renewed the Blu-ray license keys so you can continue to enjoy your Blu-ray discs, and they addressed a minor security issue that doesn't effect the homebrew community. The reason it was such a big deal is because OFW 4.87 doesn't use 4.82's version of WebKit, and this would cause a problem with HEN users. CFW users could just use SEN Enabler.

