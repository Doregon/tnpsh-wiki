---
description: We all have problems.
---

# Troubleshooting your System

## **I'm stuck in safe mode and using Restore File System or Rebuild Database freezes the system, what can I do?**

Attempt to reinstall your CFW via system update in the recovery menu. If it does not work, try Rogero or Rebug downgrader firmwares \(regardless if you are QA Flagged or not\).

