---
description: 'Hello, Redditor.'
---

# Welcome.

## This is the wiki for r/the\_new\_ps3\_homebrew! We're still working on setting it up, but feel free to take a look at what we've done so far.

### What exactly is this?

I wanted to provide an organized way of delivering the Wiki to the users, and I found the perfect platform, that looks nice and provides a good way of switching between pages. It'll use what was typed in the original wiki as a base, but...

![](.gitbook/assets/screen-shot-2020-12-16-at-7.06.36-pm.png)

I want to make this a little less messy.

The sidebar you see to the left acts as an index, you can click the arrows next to section headings to get where you need to go quickly and only have the information that you need.

### Check out the FAQ for right now, we'll get more pages added as time goes on.

