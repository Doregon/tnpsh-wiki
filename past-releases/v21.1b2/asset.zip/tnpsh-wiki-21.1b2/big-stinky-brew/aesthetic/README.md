# Aesthetics

Want to customize the what plays when your system boots to the first 8 seconds of "Crazy Train"? How about making the wave in the background all the colors of the rainbow and vertical? Changing the PSN icon to the insignia of the Assassin's Creed? Or even making the font look like it was pulled out of Need For Speed: Most Wanted 2005?

With very careful modifications to your /dev\_flash, you can! It's as easy as dropping a file in place of another and rebooting, or using a mod iso or installing an aesthetic tweak tool to pick out what you want and have it copied for you.

