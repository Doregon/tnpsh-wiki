# Custom Waves

The old wave is boring, just a white set of lines that are moving on a background that changes according to the time and day.

However, you can change it!