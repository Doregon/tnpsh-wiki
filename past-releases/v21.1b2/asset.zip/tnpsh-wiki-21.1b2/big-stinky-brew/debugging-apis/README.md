---
description: Debugging APIs
---

# Debugging APIs

Debugging APIs mainly allow you to send custom calls into your system so that you can do more with your console, but are mostly used to edit system memory for real-time modding of games and using debugger tools on DEX consoles.

Obviously, this isn't required for all users, and **can even be harmful if on HEN if you don't choose the correct one.** However, one of the mentioned in this section is bundled with webMAN MOD \(if you held L1 when installing\).

