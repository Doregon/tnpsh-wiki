# Console Control API

[Control Console API](http://store.brewology.com/ahomebrew.php?brewid=254) is a framework that allows you to read and write values and addresses in RAM in real-time using a PC or Android device over the local network. It's typically used for debugging and real time game modding. Note that in order to modify games, you must first convert their EBOOT to a [debug EBOOT](https://www.reddit.com/r/ps3homebrew/wiki/eboots). CCAPI is supported on both CEX and DEX firmwares.

**Remember that HEN users SHOULD NOT INSTALL this API!** Doing so could soft-lock your console and render it unusable.

