# BIOS Files

If your emulator core requires a BIOS file to function, you can obtain one and use an [FTP session](https://www.reddit.com/r/ps3homebrew/wiki/transferring_files) to place it in the directory: /dev_hdd0/game/SSNE10000/USRDIR/cores/system/.

It's recommended to find or rip your own BIOS in order to use RetroArch, **even if it's from RetroArch.**