# Setup

Simply install the pkg with the Install Packages option on CFW, and run RetroArch. Select Settings and then Path Settings; here you can choose what folder you want RetroArch to look for ROMs in by default and where save files and savestates will be stored. It is suggested to create the folder "/dev_hdd0/ROMS" to hold ROMs, and to create another folder "/dev_hdd0/ROMS/saves" to hold save files and savestates in case you ever need to uninstall RetroArch.
