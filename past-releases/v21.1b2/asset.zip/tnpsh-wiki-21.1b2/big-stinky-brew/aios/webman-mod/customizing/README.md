# Web Interface

**This section will run through webMAN's interface to help you know what to do to customize to your liking.** We'll start off with the /setup.ps3 page, and slowly move deeper to help you familiarize yourself with webMAN MOD.

