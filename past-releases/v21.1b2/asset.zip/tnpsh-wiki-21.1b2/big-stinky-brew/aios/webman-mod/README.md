# webMAN MOD

webMAN MOD is an all-purpose homebrew that's highly recommended for use by the community. It packs a really good punch without all the bloat, and can even be used as a replacement for multiMAN in some cases.

This section of this wiki will make webMAN seem less intimidating to the average Jill or Joe, and help you get to the features you need and customize to your liking.

