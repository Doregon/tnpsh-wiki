# Customizing

You now have multiMAN installed, and you're ready to adjust the settings and get behind the scenes. This page will introduce you to all of the little settings, and provide recommended settings.

