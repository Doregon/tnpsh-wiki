# Media Streaming

Got content on your computer or phone that you want to watch with your PlayStation 3? With a DLNA server, you can stream that content over and have it appear on the big screen.

DLNA software can be used to achieve this: [Universal Media Server](https://www.psx-place.com/threads/universal-media-server-ums-updated-to-v6-5-3.12250/) is a good choice if you want to get up and running quickly.

