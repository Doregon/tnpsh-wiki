# PC Homebrew Tools

Here's where the fun really begins.

**Collections of tools and materials made for interconnecting and modifying your PS3 with your computer further are here.** You can convert games, split files, host webservers to run games from the network, modify saves, and even \(with a full CFW\) decrypt and use your PS3 hard drive with your computer to copy files on/off easily.

All of these tools work on Windows. Development may or may not be continuing to bring these to other platforms.

