# Aldostools' Collection

This collection of programs is essential for anyone who's using their PC to mod their console. It offers the tools to help you do the following:

* Customize your console
* Make PS2/PSP games into Classics/minis
* Modify save data
* Force game EBOOTs
* View package internals
* Format any size USB as FAT32
* Edit PARAM.SFO to change names, TitleIDs, enable Remote Play and background music, and allow higher resolutions
* Run games from the network
* Install packages from the network

...among many, many other tools that you can use to make your PS3 behave the way you want.

