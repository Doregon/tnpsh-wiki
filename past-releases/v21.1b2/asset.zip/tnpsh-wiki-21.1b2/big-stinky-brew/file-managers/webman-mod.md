# webMAN MOD

## Here's the section about webMAN MOD's file management prowess.

webMAN includes an FTP server for easy viewing with a PC or phone \(yes, there are ways to use FTP on a phone now!\) and a web-based file manager for easy access to edit files quickly. This section will go in depth into the file manager apart of webMAN MOD, for anything else go into AIO &gt; webMAN MOD.

