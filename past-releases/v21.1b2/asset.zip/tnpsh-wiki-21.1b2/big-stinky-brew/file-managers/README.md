# File Managers

File managers are where your files are at. **Providing a little more oomph than the aio applications do** in the file management scene, you can do more advanced stuff such as linking with symbolic links and dealing with .zip, .rar, and even .iso files.

File management isn't required, due to the all-in-ones being able to handle basic operations for light tasks such as transferring games and installing packages. However, I'd recommend that you use a file manager **if you want to mod your system** and apply custom themes, waves, sounds, and the like, but also don't have an FTP client or don't want to use an AIO.

I use **ManaGunZ File Manager** for my file management needs, and it works well. I describe it more in the ManaGunZ section.
