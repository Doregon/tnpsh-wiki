# What's this section?

Everything in this section of the wiki is **obsolete**. Because of this, we're treating it a lit. All of the stuff explained here has either been discontinued, succeeded by something new, or patched by Sony.

We're keeping these here for historical reference, **not for you to attempt to do or install any of these things**. This is merely to show you the history of jailbreaking a PlayStation 3.

