# Installing

**Before you do anything, check to make sure that your PS3 is compatible!** Use minverchk to verity this.

