# Rebug

## For some 25xx and all earlier models, you can use Rebug for a full CFW experience.

You get the full package! With full control over your PlayStation, you can command and bend it to your will, such as re-enabling lost features, better support for homebrew, and full access to tweak your system to your liking.

Rebug is also Cobra-compatible, which means it's capable of all the plugins that PS3HEN can use.

