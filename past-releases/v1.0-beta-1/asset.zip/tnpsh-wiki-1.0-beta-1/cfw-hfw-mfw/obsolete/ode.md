# Optical Drive Emulator

Before installing CFW with USBs was really taking hold, people with phat and 2xxx consoles \(minimum version of 3.55 or lower\) used **optical drive emulators** to run PS3 game backups without the need for a jailbreak. This method was succeeded by PS3HAN, and bow PS3HEN.

Because this method has been replaced by USB installers for CFW and because of the potential risk of incompatibility if the steps are followed to initiate the process of this method, we’re not copying the optical drive emulator guides to this wiki. However, the r/ps3homebrew subreddit wiki still contains these methods and you can explore there if you so require.

