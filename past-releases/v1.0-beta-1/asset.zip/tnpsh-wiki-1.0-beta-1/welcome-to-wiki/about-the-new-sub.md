---
description: Got a question that you think has an answer?
---

# About the new Sub

## So... why is there another PS3 Homebrew sub?

Take a look at my post on the original subreddit to learn about why I made this sub. [https://www.reddit.com/r/ps3homebrew/comments/kb96bg/after\_receiving\_no\_reply/](https://www.reddit.com/r/ps3homebrew/comments/kb96bg/after_receiving_no_reply/)

## Is this sub changing at all from the last one?

Not exactly, the only real change will be the availability of moderators. I was disappointed and I strive to be online as much as I can, and the other moderators are also doing the same. We'll also be holding elections for new mods, just to make sure we're not always inactive.

