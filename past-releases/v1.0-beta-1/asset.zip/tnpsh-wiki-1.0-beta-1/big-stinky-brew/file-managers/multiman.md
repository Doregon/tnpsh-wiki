# multiMAN

## The file manager for multiMAN isn't an addon or plugin, it's directly integrated into multiMAN itself!

This section just covers \(in depth\) the file manager's features in multiMAN. For everything else, go to AIO &gt; multiMAN.

