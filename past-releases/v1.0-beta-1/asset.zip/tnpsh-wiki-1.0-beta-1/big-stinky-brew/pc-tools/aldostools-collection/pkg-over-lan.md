# Installing PKG over LAN

