# Conversions

reActPSN is capable of converting PS2 ISOs to PS2 classics, or PS3 ISOs into PSN packages.

