# CID Protection

If you are planning on using a mod tool on your PC in conjunction with CCAPI or TMAPI, **it's a good idea to block the program's Internet access** so it can't steal your ConsoleID \(CID\) and upload it to someone else if it is malicious. You can do this with the following process on Windows:

1. Head over to **Start and type "Windows Firewall"** and select the option that pops up.
2. Select **Advanced Settings → Outbound Rules \(left side\) → New Rule \(right side\)**.
3. **Follow the wizard** and select the .exe file of your mod tool and block it from Domain, Public, and Private networks.

Android doesn't have too many problems with mod tools \(probably because there aren't many out there\), but if you want to be safe with yours you can **disable mobile data and set your WiFi DNS settings to 192.168.0.1**. This will prevent any apps on your phone from connecting to the internet, though you can still access local devices.

