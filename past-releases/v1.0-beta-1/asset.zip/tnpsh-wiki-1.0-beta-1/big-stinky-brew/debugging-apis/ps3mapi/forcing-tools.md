# Using on PC

Often times, PC tools are built solely for CCAPI. You can force them to use MAPI by extracting the PS3Lib.dll into the tool's folder from [Fake CCAPI](http://www.mediafire.com/download/znig9z0dsbg6x7k/Fake_CCAPI.rar).

A set of demo tools built specifically for MAPI can be found [here](http://www.mediafire.com/download/la132l9vfpb1fba/PS3M_API_Demo_Tools.rar).

