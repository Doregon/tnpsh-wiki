# Preparing your PS3

If you have Rebug firmware or webMAN-MOD installed, you can use MAPI with any device on your network by browsing to: [your.ps3s.ip.here/home.ps3mapi](https://www.reddit.com/r/ps3homebrew/wiki/mapi)

webMAN also has a sidebar and you can select "PS3MAPI" when on the integrated web server.

A GitHub fellow by the name of jprsd has created the [Android PS3 Manager](https://github.com/jprsd/Android-PS3-Manager) for a true app-like experience to interact with your console from an Android-enabled phone or tablet.

