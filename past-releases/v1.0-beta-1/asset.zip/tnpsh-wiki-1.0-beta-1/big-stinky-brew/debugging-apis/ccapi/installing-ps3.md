# Installing on PS3

1. Install the [CCAPI Installer](http://store.brewology.com/ahomebrew.php?brewid=254) pkg on your PS3 and launch it.
2. Confirm the installation twice and allow the console to reboot. If successful, it should display a notification that CCAPI has been installed.

