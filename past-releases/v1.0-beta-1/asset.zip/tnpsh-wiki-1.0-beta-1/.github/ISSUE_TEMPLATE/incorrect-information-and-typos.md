---
name: Incorrect information and typos
about: Let's fix some problems on the wiki.
title: ''
labels: ''
assignees: ''

---

What page is it on?

What should be written?

When did you see this/is it still a problem?
